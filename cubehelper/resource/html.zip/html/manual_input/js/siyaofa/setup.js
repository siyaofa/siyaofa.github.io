create_scene()
createCube()
reset_view()

setupUIEvent()
render();