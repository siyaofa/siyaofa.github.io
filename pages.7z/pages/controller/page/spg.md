---
layout: page
title: setpoint generator
---

# Setpoint

设置生成点

预先设置被控对象需要到达的状态，和过程中的每一个状态。

[setpoint](https://en.wikipedia.org/wiki/Setpoint_(control_system))

