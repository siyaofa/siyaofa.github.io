---
layout: page
title: architecture
---

# 软件架构

主要介绍五种常用的软件架构
