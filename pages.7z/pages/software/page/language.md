---
layout: page
title: language
---

# 编程语言

目前接触的编程语言主要有:

C/C++、Python、C#和Java

C/C++主要用于驱动软件及带界面的调试软件开发。

Python用于小工具的开发。主要是因为Python的现有库较多，且无需编译。
