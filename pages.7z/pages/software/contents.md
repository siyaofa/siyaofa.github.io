---
layout: page
title: software contents
---

## [设计模式](page/design_pattern)

## [软件架构](page/architecture)

## [编程语言](page/language)

## [编译](page/compile)
