---
layout: page
title: move
---
在识别到魔方所在区域之后，我们只需要识别出魔方每个面的当前状态就可以重建出魔方整体的情况

 ![前面](../pic/Front.jpg)
 
 ![后面](https://siyaofa.github.io/pic/Back.jpg)
  
 ![左面](https://siyaofa.github.io/pic/Left.jpg)
   
 ![右面](https://siyaofa.github.io/pic/Right.jpg)
    
![上面](https://siyaofa.github.io/pic/Top.jpg)
     
![下面](https://siyaofa.github.io/pic/Bottom.jpg)

最终的视频
<video src="https://siyaofa.github.io/video/stepByStep.mp4" controls="controls">
您的浏览器不支持 video 标签。
</video>



[还原视频](http://v.youku.com/v_show/id_XMjcwMzk0NDM3Ng==.html)

