---
layout: page
title: 微分方程
---

# 微分方程

微分方程的由来

微分方程的意义