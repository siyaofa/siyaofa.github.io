---
layout: page
title: hardware contents
---

## 总线

## FPGA


### HDL

硬件描述语言

*Note*:硬件编程和软件
{: note}

#### Verilog

语法设计参考C语言。



#### VHDL

